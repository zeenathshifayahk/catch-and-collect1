(() => {
  const gameArea = document.getElementById("game-area");
  const player = document.getElementById("player");

  const scoreEl = document.getElementById("score");
  const livesEl = document.getElementById("lives");
  const levelEl = document.getElementById("level");

  const startBtn = document.getElementById("startBtn");
  const pauseBtn = document.getElementById("pauseBtn");
  const resetBtn = document.getElementById("resetBtn");

  // NEW SCREENS
  const startScreen = document.getElementById("start-screen");
  const gameoverScreen = document.getElementById("gameover-screen");
  const finalScore = document.getElementById("finalScore");
  const playBtn = document.getElementById("playBtn");
  const restartBtn = document.getElementById("restartBtn");

  // Game State
  let score = 0;
  let lives = 5;
  let level = 1;
  let running = false;

  let items = [];
  let lastFrame = null;
  let lastSpawn = 0;
  let spawnInterval = 900;
  let itemSpeed = 160;

  let audioCtx = null;
  let muted = false;

  const FRUITS = [
    { e: "🍎", v: 10 },
    { e: "🍌", v: 12 },
    { e: "🍇", v: 14 },
    { e: "🍓", v: 16 },
    { e: "🍍", v: 20 },
    { e: "🍒", v: 12 },
    { e: "🍉", v: 18 }
  ];

  const BOMB = { e: "💣", v: -1 };

  function ensureAudio() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }

  function playTone(freq=440, type="sine", dur=0.08, gain=0.08){
    if (muted) return;
    ensureAudio();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, audioCtx.currentTime);
    g.gain.setValueAtTime(gain, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
    o.connect(g);
    g.connect(audioCtx.destination);
    o.start();
    o.stop(audioCtx.currentTime + dur + 0.02);
  }

  function playCollect(){ playTone(880); setTimeout(()=>playTone(1100,'triangle',0.06,0.06),60); }
  function playBomb(){ playTone(520,'square'); }
  function playMiss(){ playTone(220); setTimeout(()=>playTone(160),100); }

  function spawnItem(isBomb=false) {
    const rect = gameArea.getBoundingClientRect();
    const x = Math.random() * (rect.width - 60) + 20;
    const meta = isBomb ? BOMB : FRUITS[Math.floor(Math.random()*FRUITS.length)];

    const el = document.createElement("div");
    el.className = "item";
    if (isBomb) el.classList.add("bomb");
    el.textContent = meta.e;
    el.dataset.value = meta.v;
    el.style.left = x + "px";
    el.style.top = "-60px";

    gameArea.appendChild(el);

    items.push({
      el,
      x,
      y: -60,
      vy: itemSpeed * (0.9 + Math.random()*0.6)
    });
  }

  function emitParticles(x,y) {
    for (let i=0; i<6; i++){
      const p = document.createElement("div");
      p.className = "particle";
      p.textContent = ["✨","⭐","💥","🍃"][Math.floor(Math.random()*4)];
      gameArea.appendChild(p);

      const angle = Math.random()*Math.PI*2;
      const speed = 80 + Math.random()*100;
      const life = 600 + Math.random()*600;
      const start = performance.now();

      p.style.left = x + "px";
      p.style.top = y + "px";

      requestAnimationFrame(function frame(t){
        const dt = (t - start)/1000;
        const dx = Math.cos(angle)*speed*dt;
        const dy = Math.sin(angle)*speed*dt;

        p.style.transform = `translate(${dx}px, ${dy}px) scale(${1 - dt})`;
        p.style.opacity = `${1 - dt}`;

        if (dt < 1) requestAnimationFrame(frame);
        else p.remove();
      });
    }
  }

  function rect(el){ return el.getBoundingClientRect(); }
  function overlap(a,b){
    return !(a.right<b.left || a.left>b.right || a.bottom<b.top || a.top>b.bottom);
  }

  function addScore(v){
    score += v;
    scoreEl.textContent = "Score: " + score;
  }

  function loseLife(){
    lives--;
    livesEl.textContent = "Lives: " + lives;
    if (lives <= 0) endGame();
  }

  function endGame(){
    running = false;
    finalScore.textContent = "Your score: " + score;
    gameoverScreen.style.display = "flex";
  }

  function resetGame(){
    running = false;
    score = 0;
    lives = 5;
    level = 1;
    items.forEach(it => it.el.remove());
    items = [];

    scoreEl.textContent = "Score: 0";
    livesEl.textContent = "Lives: 5";
    levelEl.textContent = "Level: 1";
  }

  function startGame(){
    startScreen.style.display = "none";
    gameoverScreen.style.display = "none";

    running = true;
    lastFrame = null;

    requestAnimationFrame(gameLoop);
  }

  function gameLoop(ts){
    if (!running){ lastFrame = ts; return; }
    if (!lastFrame) lastFrame = ts;

    const dt = (ts - lastFrame)/1000;
    lastFrame = ts;

    level = Math.floor(score/200)+1;
    levelEl.textContent = "Level: " + level;

    itemSpeed = 150 + (level-1)*30;
    spawnInterval = Math.max(250, 900 - (level-1)*80);

    if (ts - lastSpawn > spawnInterval){
      lastSpawn = ts;

      const isBomb = Math.random() < (0.12 + (level-1)*0.03);
      spawnItem(isBomb);

      if (Math.random() < 0.12) spawnItem(false);
    }

    const pRect = rect(player);

    for (let i=items.length-1; i>=0; i--){
      const it = items[i];
      it.y += it.vy*dt;
      it.el.style.top = it.y + "px";

      const r = rect(it.el);

      if (overlap(r,pRect)){
        const val = parseInt(it.el.dataset.value);

        if (val < 0){
          loseLife();
          playBomb();
        } else {
          addScore(val);
          emitParticles(r.left + r.width/2, r.top + r.height/2);
          playCollect();
        }

        it.el.remove();
        items.splice(i,1);
        continue;
      }

      if (it.y > gameArea.clientHeight){
        if (parseInt(it.el.dataset.value)>0){
          loseLife();
          playMiss();
        }

        it.el.remove();
        items.splice(i,1);
      }
    }

    requestAnimationFrame(gameLoop);
  }

  // Mouse control
  gameArea.addEventListener("mousemove", e=>{
    const rect = gameArea.getBoundingClientRect();
    player.style.left = (e.clientX - rect.left) + "px";
  });

  // Keyboard control
  document.addEventListener("keydown", e=>{
    if (e.key === " "){
      running = !running;
      if (running) requestAnimationFrame(gameLoop);
      return;
    }

    const x = player.offsetLeft;
    const step = 40;

    if (e.key==="ArrowLeft") player.style.left = (x-step)+"px";
    if (e.key==="ArrowRight") player.style.left = (x+step)+"px";
  });

  // Buttons
  startBtn.onclick = startGame;
  pauseBtn.onclick = () => running=false;
  resetBtn.onclick = resetGame;

  playBtn.onclick = startGame;
  restartBtn.onclick = () => { resetGame(); startGame(); };

})();
