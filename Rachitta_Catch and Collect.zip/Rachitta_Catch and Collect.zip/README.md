🍌 Catch & Collect Game – HTML | CSS | JavaScript
*👋 Hey Developer!*

Welcome to the Catch & Collect Game Project!
In this fun project, you will build an interactive browser game where a basket catches falling fruits while avoiding bombs. This project strengthens your HTML, CSS, and JavaScript skills while helping you build something playful and creative.

**🎮 What You’ll Build**

You will create a fully interactive Catch & Collect Browser Game.

**The game includes:**

✔ Falling fruits (🍎🍌🍇🍍)
✔ Bombs to avoid (💣)
✔ Moving basket controlled by keyboard, mouse, or touch
✔ Score and lives tracking
✔ Increasing difficulty with levels
✔ Sound effects & animations
✔ Smooth responsive gameplay

**📦 Your Project Includes**
*Your main files:*
index.html → Structure of the game
styles.css → Layout, colors, animations
script.js → Game logic, movement, score, collisions, sounds

All files must be in the same folder.

**🧱 Constraints (What You MUST Use)**
*Please ensure your project follows these rules:*

HTML Requirements
Use a <header> for the game title.
Use a main <div id="game-area"> for the gameplay area.

*Include:*
A player basket

*UI sections for:*
Score
Lives
Level
Add start, pause, and reset buttons.

*Link external:*
styles.css (CSS)
script.js (JavaScript)
CSS Requirements

**Your CSS must include:**

✔ Centered game area
✔ Fixed dimensions for the game box
✔ Styled basket
✔ Styled falling items
*✔ Animations for:*
item collection
score pulse
player shake
✔ A clean, simple theme

**JavaScript Requirements**

*Your JavaScript must:*
✔ Spawn fruits & bombs
✔ Move basket left/right
✔ Detect collisions
✔ Update score & lives
✔ Trigger sounds
✔ End the game when lives reach 0
✔ Increase difficulty as score increases
✔ Use requestAnimationFrame() for smooth animation

**🚀 How to Run the Game**

Open the project folder in VS Code

Right-click index.html

Click “Open With Live Server”
→ Or simply open it in your browser

**🧪 Quick Troubleshooting**
*❗CSS Not Working?*

**If the console shows:**

GET styles.css net::ERR_FILE_NOT_FOUND


✔ Ensure the file is named styles.css
✔ Ensure it is in the same folder
*✔ Check HTML contains:*
<link rel="stylesheet" href="styles.css">

*❗JavaScript Not Running?*

**Console shows:**

GET script.js net::ERR_FILE_NOT_FOUND


✔ File must be named script.js
✔ Must be in the same folder
✔ HTML must include:

<script src="script.js" defer></script>

**Team Members**
HTML - G.Rachitta
CSS  - C.Madhu Latha
JS   - Zeenath shifaya H K

 GitHub Repository URL: https://github.com/rachittags140-gif/catch-and-collect-game.git

**⭐ Final Note**

This game is a great practice project for mastering DOM manipulation, animations, and event handling in JavaScript.
Feel free to improve and customize it however you like!

